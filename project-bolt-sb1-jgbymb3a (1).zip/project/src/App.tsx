import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginPage from './components/LoginPage';
import OTPVerification from './components/OTPVerification';
import Dashboard from './components/Dashboard';

function AppContent() {
  const { user, login } = useAuth();
  const [step, setStep] = useState<'login' | 'otp' | 'dashboard'>('login');
  const [tempEmail, setTempEmail] = useState('');
  const [displayedOtp, setDisplayedOtp] = useState('');

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;

  const handleLogin = async (email: string, password: string) => {
    const response = await fetch(`${supabaseUrl}/functions/v1/send-otp`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Login failed');
    }

    setTempEmail(email);
    setDisplayedOtp(data.otpCode);
    setStep('otp');
  };

  const handleVerifyOTP = async (otp: string) => {
    const response = await fetch(`${supabaseUrl}/functions/v1/verify-otp`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: tempEmail, otp }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'OTP verification failed');
    }

    login(data.user);
    setStep('dashboard');
  };

  const handleResendOTP = async () => {
    setDisplayedOtp('');
  };

  const handleFileUpload = async (file: File) => {
    if (!user) throw new Error('User not authenticated');

    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', user.id);

    const response = await fetch(`${supabaseUrl}/functions/v1/upload-report`, {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Upload failed');
    }

    return { fileUrl: data.fileUrl, tests: data.tests };
  };

  if (user && step === 'dashboard') {
    return <Dashboard onFileUpload={handleFileUpload} />;
  }

  if (step === 'otp') {
    return (
      <>
        <OTPVerification
          email={tempEmail}
          onVerify={handleVerifyOTP}
          onResend={handleResendOTP}
        />
        {displayedOtp && (
          <div className="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg">
            <p className="text-sm font-medium">Demo OTP Code: {displayedOtp}</p>
          </div>
        )}
      </>
    );
  }

  return <LoginPage onLoginSubmit={handleLogin} />;
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
