"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

export default function UploadPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [error, setError] = useState("")

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0]
      if (["application/pdf", "image/jpeg", "image/png"].includes(droppedFile.type)) {
        setFile(droppedFile)
        setError("")
      } else {
        setError("Please upload a PDF or image file (JPG/PNG)")
      }
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]
      if (["application/pdf", "image/jpeg", "image/png"].includes(selectedFile.type)) {
        setFile(selectedFile)
        setError("")
      } else {
        setError("Please upload a PDF or image file (JPG/PNG)")
      }
    }
  }

  const handleUpload = async () => {
    if (!file) return

    setLoading(true)
    setError("")

    try {
      console.log("[v0] Starting mock upload for file:", file.name)

      // Simulate upload delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mock successful upload response
      const mockUploadId = `upload_${Date.now()}`
      const mockAnalysis = {
        uploadId: mockUploadId,
        fileName: file.name,
        tests: [
          { name: "Hemoglobin", value: "14.5", unit: "g/dL", normalRange: "13.5-17.5" },
          { name: "White Blood Cells", value: "7.2", unit: "K/uL", normalRange: "4.5-11.0" },
          { name: "Platelets", value: "245", unit: "K/uL", normalRange: "150-400" },
          { name: "Glucose", value: "95", unit: "mg/dL", normalRange: "70-100" },
        ],
        status: "success",
      }

      console.log("[v0] Mock upload successful:", mockUploadId)

      sessionStorage.setItem("uploadId", mockUploadId)
      sessionStorage.setItem("uploadData", JSON.stringify(mockAnalysis))

      toast({
        title: "Success",
        description: "Report uploaded successfully",
      })

      router.push("/report")
    } catch (err: any) {
      console.log("[v0] Upload error:", err)
      const errorMsg = err.response?.data?.message || "Upload failed. Please try again."
      setError(errorMsg)
      toast({
        title: "Error",
        description: errorMsg,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-2xl mx-auto py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Upload Medical Report</h1>
          <p className="text-muted-foreground">Upload a PDF or image of your medical report for analysis</p>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Select File</CardTitle>
            <CardDescription>Drag and drop or browse your file</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors cursor-pointer ${
                dragActive ? "border-blue-600 bg-blue-50" : "border-border hover:border-blue-400"
              }`}
            >
              <input
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileSelect}
                className="hidden"
                id="file-input"
              />
              <label htmlFor="file-input" className="cursor-pointer block">
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
                <p className="text-base font-medium text-foreground mb-1">
                  {file ? file.name : "Drop your file here or click to browse"}
                </p>
                <p className="text-sm text-muted-foreground">PDF or image files (JPG, PNG) up to 10MB</p>
              </label>
            </div>

            {file && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm font-medium text-foreground">
                  File selected: <span className="text-blue-600">{file.name}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-1">Size: {(file.size / 1024 / 1024).toFixed(2)}MB</p>
              </div>
            )}

            <Button
              onClick={handleUpload}
              disabled={!file || loading}
              className="w-full bg-blue-600 hover:bg-blue-700"
              size="lg"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                "Upload Report"
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
