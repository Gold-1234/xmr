"use client"

import { useState, useEffect, useRef } from "react"
import axios from "axios"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface BoundingBox {
  x: number
  y: number
  width: number
  height: number
  testName: string
}

interface Explanation {
  testName: string
  explanation: string
}

export default function ReportPage() {
  const [imageUrl, setImageUrl] = useState("")
  const [boxes, setBoxes] = useState<BoundingBox[]>([])
  const [selectedBox, setSelectedBox] = useState<BoundingBox | null>(null)
  const [explanation, setExplanation] = useState<Explanation | null>(null)
  const [loading, setLoading] = useState(true)
  const [explainLoading, setExplainLoading] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    const loadReportData = async () => {
      try {
        const uploadDataStr = sessionStorage.getItem("uploadData")
        if (uploadDataStr) {
          const uploadData = JSON.parse(uploadDataStr)
          setImageUrl(uploadData.imageUrl || "/medical-report.jpg")

          // Parse bounding boxes from the response
          if (uploadData.boundingBoxes) {
            setBoxes(uploadData.boundingBoxes)
          } else {
            // Mock data for demo
            setBoxes([
              { x: 50, y: 100, width: 150, height: 50, testName: "Blood Sugar" },
              { x: 250, y: 150, width: 120, height: 40, testName: "Hemoglobin" },
              { x: 100, y: 300, width: 180, height: 60, testName: "Vidal Test" },
            ])
          }
        }
      } catch (err) {
        toast({
          title: "Error",
          description: "Failed to load report data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadReportData()
  }, [toast])

  const handleBoxClick = async (box: BoundingBox) => {
    setSelectedBox(box)
    setExplainLoading(true)
    setExplanation(null)
    setShowModal(true)

    try {
      const token = sessionStorage.getItem("token")
      const response = await axios.get(
        `http://localhost:5000/api/explain?testName=${encodeURIComponent(box.testName)}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )

      setExplanation({
        testName: box.testName,
        explanation: response.data.explanation || "No explanation available",
      })
    } catch (err: any) {
      toast({
        title: "Error",
        description: "Failed to load explanation",
        variant: "destructive",
      })
    } finally {
      setExplainLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-foreground font-medium">Loading report...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Medical Report Analysis</h1>
          <p className="text-muted-foreground">Click on highlighted areas to see test explanations</p>
        </div>

        <Card className="shadow-lg overflow-hidden">
          <CardHeader>
            <CardTitle>Report Image</CardTitle>
          </CardHeader>
          <CardContent>
            <div ref={containerRef} className="relative inline-block w-full">
              <img
                src={imageUrl || "/placeholder.svg"}
                alt="Medical Report"
                className="w-full h-auto rounded-lg shadow-md"
              />

              {/* Overlay bounding boxes */}
              {boxes.map((box, index) => (
                <button
                  key={index}
                  onClick={() => handleBoxClick(box)}
                  className="absolute border-2 border-blue-500 hover:bg-blue-500 hover:bg-opacity-20 transition-colors cursor-pointer rounded"
                  style={{
                    left: `${box.x}px`,
                    top: `${box.y}px`,
                    width: `${box.width}px`,
                    height: `${box.height}px`,
                  }}
                  title={box.testName}
                >
                  <span className="text-xs font-bold text-blue-600 bg-white bg-opacity-90 px-1 py-0.5 rounded whitespace-nowrap">
                    {box.testName}
                  </span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Explanation Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span className="text-blue-600 font-semibold">{selectedBox?.testName}</span>
              <span className="text-muted-foreground text-sm font-normal">Explanation</span>
            </DialogTitle>
            <DialogDescription>Information about the selected medical test</DialogDescription>
          </DialogHeader>

          {explainLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
            </div>
          ) : explanation ? (
            <div className="py-4">
              <p className="text-foreground leading-relaxed">{explanation.explanation}</p>
            </div>
          ) : null}

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
