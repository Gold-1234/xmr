"use client"

import { useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"

export default function ProtectedLayout({ children }: { children: ReactNode }) {
  const router = useRouter()

  useEffect(() => {
    const isVerified = sessionStorage.getItem("isVerified")
    if (!isVerified) {
      router.push("/login")
    }
  }, [router])

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>{children}</main>
    </div>
  )
}
