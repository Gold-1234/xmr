"use client"

import { useRouter, usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { LogOut, Home } from "lucide-react"

export function Navbar() {
  const router = useRouter()
  const pathname = usePathname()

  const handleLogout = () => {
    sessionStorage.clear()
    router.push("/login")
  }

  const handleHome = () => {
    router.push("/upload")
  }

  return (
    <nav className="border-b border-border bg-background shadow-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">MR</span>
          </div>
          <div>
            <h1 className="font-semibold text-foreground">Medical Report Analyzer</h1>
            <p className="text-xs text-muted-foreground">AI-Powered Analysis</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {pathname !== "/upload" && (
            <Button variant="ghost" size="sm" onClick={handleHome} className="gap-2">
              <Home className="h-4 w-4" />
              Upload
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-destructive hover:text-destructive gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </nav>
  )
}
